# Paul Transformation Webapp TODO

- [x] Eigenständiges React-Vite-Projekt mit Framer Motion und Lucide anlegen
- [x] Originales PCT-Logo, Portrait und vorhandene Bildassets in die neue Webapp übernehmen
- [x] Filmischen Parallax-Hero mit zugänglichem Reduced-Motion-Fallback implementieren
- [x] Hürden-Sektion „Du brauchst nicht mehr Druck“ mit konkreten Ursachen, visueller Spannung und klarer Überleitung zum PCT-System ausbauen
- [x] Alle Hauptsektionen mit performanten Scroll-Übergängen, Tiefenebenen und zugänglichem Reduced-Motion-Fallback verbinden
- [x] Hürdenabschnitt und PCT-Dreiklang als Scroll-Erlebnis umsetzen
- [x] Transformations-Rechner mit transparenter, nicht-medizinischer Orientierung und Validierung umsetzen
- [x] Direkte Wix-Buchungsbuttons für Erstgespräch und Bootcamp integrieren
- [x] Kontakt- und Rechner-Lead-Formulare als datensparsame Frontend-Entwürfe implementieren
- [ ] Datenbankanbindung erst in einem separat provisionierten Full-Stack-Projekt ergänzen; ZugangSafe bleibt unberührt
- [ ] Keine Testimonials, Bewertungen, Vorher-Nachher-Zahlen oder Erfolgskennzahlen ohne echte Freigabe verwenden
- [x] Vitest-Tests für Rechnerlogik und Formularvalidierung ergänzen
- [x] Desktop- und mobile Darstellung sowie prefers-reduced-motion prüfen
- [x] Eigenständige Vorschau starten und Übergabe-Artefakte erstellen
