# Inhalts- und Interaktionsarchitektur

## 1. Einstieg: Entscheidung statt Druck

Der Hero verwendet das vorhandene PCT-Portrait und die vier vorhandenen Bewegungsframes als visuellen Anker. Die Kernbotschaft lautet **„Transformiere deinen Körper. Beherrsche deinen Geist.“**. Der primäre CTA führt zum Erstgespräch; ein zweiter CTA führt zu den Programmen. Es gibt keine unbestätigten Erfolgszahlen oder erfundenen Social-Proof-Elemente.

## 2. Hürden: Alltag sichtbar machen

Die nächste Sequenz führt drei typische, im Prompt genannte Hürden ein: Stagnation, wenig Energie nach einem Arbeitstag und Frust durch unpassende Diäten. Sie werden als Reflexionsfragen formuliert, nicht als Diagnose oder Versprechen.

## 3. Das PCT-System: Drei Säulen

Die drei Säulen werden als sticky Scroll-Kapitel ausgeführt. Ihre Inhalte bleiben aus dem bestehenden PCT-Angebot abgeleitet: strukturiertes Training, alltagstaugliche Ernährung sowie mentale Begleitung und kontinuierliche Anpassung.

## 4. Orientierungs-Rechner

Der Rechner fragt nur Altersgruppe, Hauptziel und Trainingserfahrung ab. Die Ausgabe ist eine neutrale Zeitspanne als **unverbindliche Orientierung**. Sie ersetzt keine medizinische, therapeutische oder ernährungsmedizinische Einschätzung.

## 5. Direkte Terminwahl

Der neue Buchungsbereich bleibt frei von Wix-iframe-Inhalten. Zwei klar erkennbare PCT-Buttons öffnen den offiziellen Link für das Online-Erstgespräch oder das Fit for Christ Bootcamp in einem neuen Fenster.

## 6. Kontakt

Das Kontaktformular fokussiert sich auf Name, E-Mail-Adresse, optionale Telefonnummer und Zielbeschreibung. Die sichtbare Copy nennt den Verwendungszweck der Kontaktaufnahme; Speicherung wird erst im separaten Full-Stack-Projekt aktiviert.
