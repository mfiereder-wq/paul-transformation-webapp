import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    allowedHosts: ['4174-iwzqs5ttj0yq3a4gir7gc-df76036a.us4.manus.computer'],
  },
})
