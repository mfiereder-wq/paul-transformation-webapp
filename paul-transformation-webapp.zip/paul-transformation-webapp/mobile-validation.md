# Mobile Sichtprüfung

Die neue React-Webapp wurde im vorhandenen 375-Pixel-iframe geöffnet. Hero, kompakte Kopfzeile, Menüschalter, beide Einstiegs-CTAs sowie die Responsive-Assets werden geladen. Die Hero-Hauptaussage wurde anschließend auf eine kleinere mobile Schriftgröße angepasst, damit die lange erste Zeile vollständig innerhalb des Viewports bleibt.

Die Rechner-, Kontakt- und direkten Terminaktionen sind im mobilen Dokument vorhanden. Die Wix-Buchung wird weiterhin nicht eingebettet, sondern ausschließlich über die beiden eindeutig beschrifteten, externen PCT-Buttons geöffnet.
