# Paul Christian Transformation – separate Webapp

Diese React/Vite-Webapp ist ein **eigenständiger Neuaufbau** der PCT-Landingpage. Sie liegt bewusst außerhalb von Kunden-ZugangSafe und greift weder auf dessen Code noch auf dessen Daten zu.

## Enthaltene Funktionen

| Bereich | Status |
|---|---|
| Filmischer Parallax-Hero und scrollgeführte PCT-Kapitel | Implementiert |
| PCT-System aus Training, Ernährung und mentaler Begleitung | Implementiert |
| Nicht-medizinischer Transformations-Rechner | Implementiert und getestet |
| Erstgesprächs- und Bootcamp-Buchung | Direkte offizielle Wix-Links |
| Kontaktformular | Validiert; bereitet eine E-Mail an `welcome@pctransformation.ch` vor |
| Rechner-Leadformular | Validiert; keine Daten werden in diesem reinen Frontend gespeichert |
| Datenbank für Anfragen und Rechner-Leads | Ausstehend; nur in einem separat provisionierten Full-Stack-Projekt umzusetzen |

## Lokal starten

```bash
pnpm install
pnpm dev --host 0.0.0.0 --port 4174
```

## Qualitätssicherung

```bash
pnpm test
pnpm build
```

Die automatisierten Tests decken die Rechnerlogik ab. Die Oberfläche wurde im Desktop-Browser und in einer 375-Pixel-Prüfansicht kontrolliert. Die Ansicht für reduzierte Bewegung wird über `prefers-reduced-motion` berücksichtigt.

## Nächster Ausbauschritt

Für eine echte Speicherung von Kontakt- und Rechner-Leads muss ein **neues, eigenständiges Full-Stack-Projekt mit eigener Datenbank** provisioniert werden. Erst dann werden die zwei vorgesehenen Tabellen `contact_inquiries` und `calculator_leads` eingeführt. ZugangSafe bleibt dabei vollständig unangetastet.
