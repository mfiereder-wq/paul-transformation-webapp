# Scroll-Bewegungsdramaturgie

| Abschnitt | Übergang | Abschnittsinteraktion |
|---|---|---|
| Hero | langsamer Bild-Zoom, Verschiebung der Textlage und zurückweichendes Raster | Die Einstiegsebene reagiert kontinuierlich auf den ersten Scrollabschnitt |
| Hürden | heller Vorhang mit vertikalen Textspuren | Headline, Einordnung und Karten folgen nacheinander; das Trainingsbild bleibt als ruhiger Anker |
| PCT-System | dunkler, seitlicher Bühnenwechsel | Die linke Systembotschaft hält visuell stand, während die drei Säulen in Staffelung eintreffen |
| Rechner | tiefes Anheben aus dem dunklen Hintergrund | Text- und Rechenpanel bewegen sich gegensätzlich, ohne die Eingabefelder zu stören |
| Paul | Bildausschnitt und Textkarte gleiten gegeneinander | Das Portrait erhält eine dezente Parallax-Ebene, die Copy bleibt stabil lesbar |
| Buchung | warmer Akzentwechsel und sequenzielle Kartenenthüllung | Erstgespräch und Bootcamp erscheinen als klare, antippbare Entscheidungspunkte |
| Kontakt | ruhiger Abschluss mit aufsteigender Formularfläche | Kontakttext und Formular werden als letzter, fokussierter Handlungsschritt gesetzt |

Alle Übergänge nutzen nur `transform` und `opacity`, setzen auf GPU-freundliche Bewegung und bleiben mit `prefers-reduced-motion` statisch. Eingaben, Buttons und Links werden nicht mit langwierigen Animationen belastet.
