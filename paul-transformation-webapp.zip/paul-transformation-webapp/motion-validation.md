# Bewegungsprüfung

Die Browserprüfung bestätigt sechs animierte Hauptsektionen: Hürden, PCT-System, Rechner, Paul, Buchung und Kontakt. Zusätzlich ist die scrollgebundene Orbit-Ebene im Hero vorhanden. Die drei PCT-Systemkarten sind als gestaffelte Animationselemente angelegt.

Die Bewegungslogik setzt auf `transform` und `opacity`. Interaktive Eingaben bleiben frei von langen Scroll-Animationen. Für `prefers-reduced-motion` werden Bewegungsdistanzen auf null gesetzt und dekorative Ebenen ausgeblendet.

Die Desktop-Sichtprüfung zeigt eine ruhige Hero-Orbit-Ebene sowie den dunklen Systemübergang mit gestaffelten Säulen. Die 375-Pixel-Ansicht bestätigt, dass die Orbit-Ebene mobil innerhalb der Hero-Bühne bleibt und die Text- und Buchungs-CTAs lesbar bleiben.

Die mobile Sichtprüfung der Terminwahl bestätigt zwei klar getrennte, gut antippbare Buchungskarten innerhalb der animierten Buchungsszene. Alle sechs Bewegungsabschnitte sind im mobilen Dokument vorhanden.
